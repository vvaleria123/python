nodes = set()

class Node:
    def __init__(self, key, depth):
        self.key = key
        self.depth = depth
        self.struct = ((1 + depth) * key * key) % M #.///
        self.left = None
        self.right = None
        self.parent = None




def construct_tree(node, LA, RA, M, C0, C1L, C1R, S, D):
    nodes.add(node)
    if node.struct < C0 or node.depth == D:
        return
    if C0 <= node.struct < C1L:
        node.left = Node((LA * (node.key * node.key)) % M, node.depth + 1)
        node.left.parent = node
        node.children_changed = True
        construct_tree(node.left, LA, RA, M, C0, C1L, C1R, S, D)
    elif C1L <= node.struct < C1R:
        node.right = Node((RA * (node.key * node.key)) % M, node.depth + 1)
        node.right.parent = node
        construct_tree(node.right, LA, RA, M, C0, C1L, C1R, S, D)
    elif C1R <= node.struct < M:
        node.left = Node((LA * (node.key * node.key)) % M, node.depth + 1)
        node.left.parent = node
        construct_tree(node.left, LA, RA, M, C0, C1L, C1R, S, D)
        node.right = Node((RA * (node.key * node.key)) % M, node.depth + 1)
        node.right.parent = node
        construct_tree(node.right, LA, RA, M, C0, C1L, C1R, S, D)

def get_cost(node):
    if node is None:
        return 0
    
    if node.left is not None and node.right is not None:
        return node.key + get_cost(node.left) + get_cost(node.right)
    else:
        return get_cost(node.left) + get_cost(node.right)
        

      

def get_reduced_cost(node):
    if node is None or (node.left is None and node.right is None):
        return 0
    
    return node.key + get_reduced_cost(node.left) + get_reduced_cost(node.right)
    
def l_heavy_nodes(node):
    if node is None:
        return 0
    left_leaves = count_leaves(node.left) if node.left else 0
    right_leaves = count_leaves(node.right) if node.right else 0
    return (1 if left_leaves > right_leaves else 0) + l_heavy_nodes(node.left) + l_heavy_nodes(node.right)

def count_leaves(node):    # helper for l_heavy_nodes
    if node is None:
        return 0
    if node.left is None and node.right is None:
        return 1
    return count_leaves(node.left) + count_leaves(node.right)


def calculate_dominance(node, root_value):
    if node is None:
        return 0
    
    if node.key < root_value: 
        current_count = 1 
    else:
        current_count = 0

    return current_count + calculate_dominance(node.left, root_value) + calculate_dominance(node.right, root_value)

def dominance(node):
    if node is None:
        return 0
        
    count = calculate_dominance(node, node.key)

    return count + dominance(node.left) + dominance(node.right)

def is_grandchildren_complete(node):
    if node is None:
        return False
    if node.left is not None and node.right is not None:
        return node.left.left is not None and node.left.right is not None and node.right.left is not None and node.right.right is not None
    return False


def count_grandchildren_complete(node):
    if node is None:
        return 0
    count = 0
    if is_grandchildren_complete(node):
        count += 1
    count += count_grandchildren_complete(node.left)
    count += count_grandchildren_complete(node.right)
    return count

def is_separated_leaf(node):
    if node is None:
        return False
    if node.left is None and node.right is None:  # Check if node is a leaf
        parent = node.parent
        if parent is None:
            return True  # Root node is considered as separated leaf if it has no children
        if parent.left is node and (parent.right is None or parent.right.left is not None or parent.right.right is not None):
            return True
        if parent.right is node and (parent.left is None or parent.left.left is not None or parent.left.right is not None):
            return True
    return False

def count_separated_leaves(node):
    if node is None:
        return 0
    count = 0
    if is_separated_leaf(node):
        count += 1
    count += count_separated_leaves(node.left)
    count += count_separated_leaves(node.right)
    return count

def is_case_complete(node):
    if node is None:
        return False

    has_leaf = has_two_children_node = has_left_child_only = has_right_child_only = False
    stack = [node]
    while stack:
        current = stack.pop()
        if current.left is None and current.right is None:
            has_leaf = True
        if current.left is not None and current.right is not None:
            has_two_children_node = True
        if current.left is not None and current.right is None:
            has_left_child_only = True
        if current.left is None and current.right is not None:
            has_right_child_only = True
        if current.left is not None:
            stack.append(current.left)
        if current.right is not None:
            stack.append(current.right)
    return has_leaf and has_two_children_node and has_left_child_only and has_right_child_only


def count_case_complete(node):
    if node is None:
        return 0
    count = 0
    if is_case_complete(node):
        count += 1
    count += count_case_complete(node.left)
    count += count_case_complete(node.right)
    return count


def max_bounded_path_value(node):
    if node is None:
        return 0

    # Start from each leaf node and traverse up to the root
    leaves = get_leaves(node)
    max_value = 0
    for leaf in leaves:
        path_value = leaf.key
        current = leaf.parent
        while current is not None and current.key < leaf.key:
            path_value += current.key
            current = current.parent
        max_value = max(max_value, path_value)
    return max_value

def get_leaves(node):
    if node is None:
        return []
    if node.left is None and node.right is None:
        return [node]
    return get_leaves(node.left) + get_leaves(node.right)

    

# Function to compute different characteristics of the tree
def compute_characteristic(node, P):
    if P == 1:
        return get_cost(node)
    elif P == 2:
        return get_reduced_cost(node)
    elif P == 3:
        return l_heavy_nodes(node)
    elif P == 4:
        return dominance(node)
    elif P == 5:
        return count_grandchildren_complete(node)
    elif P == 6:
        return count_separated_leaves(node)
    elif P == 7:
        return count_case_complete(node)
    elif P == 8:
        return max_bounded_path_value(node)




# Parse input
LA, RA, M, C0, C1L, C1R, S, D, Rkey = map(int, input().split())
P = int(input())

# Construct the tree
tree_root = Node(Rkey, 0)
construct_tree(tree_root, LA, RA, M, C0, C1L, C1R, S, D)

# Compute the specified characteristic
result = compute_characteristic(tree_root, P)

# Output the result
print(result)