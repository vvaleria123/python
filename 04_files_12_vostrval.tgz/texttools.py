from collections import Counter

def compute_word_importance(fpath1, fpath2):
    # Open the first file for reading
    file1 = open(fpath1, "r")
    # Open the second file for reading
    file2 = open(fpath2, "r")

    word_count1 = {}  # Store word counts from the first file
    for line in file1.readlines():
        line = line.strip()
        # Split the line using " "
        words1 = line.split(" ")
        for word in words1:
            if word in word_count1:
                word_count1[word] = word_count1[word] + 1
            else:
                word_count1[word] = 1

    word_count2 = {}  # Store word counts from the second file
    for line1 in file2.readlines():
        line1 = line1.strip()
        words2 = line1.split(" ")
        for word2 in words2:
            if word2 in word_count2:
                word_count2[word2] = word_count2[word2] + 1
            else:
                word_count2[word2] = 1

    word_importance = {}  # Store word importance
    for key in word_count1:
        if key == '':
            continue  # Skip empty strings
        word_importance[key] = word_count1[key]

    for key1 in word_count2:
        if key1 == '':
            continue  # Skip empty strings
        if key1 in word_importance:
            word_importance[key1] -= word_count2[key1]
        else:
            word_importance[key1] = -word_count2[key1]
    # Close the file
    file1.close()
    file2.close()

    # Return a Counter containing word importance
    return Counter(word_importance)


