def load_library(lib_fpath):
    # Function to load library from a file and return a dictionary
    result = {}
    # Open the file in read mode
    myfile = open(lib_fpath, "r")
    # Read each line in the file
    for line in myfile.readlines():
        # Remove the newline from the end of the line
        delt = line.rstrip("\n")
        # Split the line using "|"
        fer = delt.split("|")
        
        # Create a dictionary where the key is the first element, and the value is the second element
        result[fer[0]] = fer[1]
    # Close the file
    myfile.close()
    # Return the dictionary
    return result

def index_by_author(lib):
    # Function to index books by author from the library dictionary
    index_of_books = {}
    
    # Iterate through the items in the dictionary
    for item in lib:
        author = lib[item]  # author
        book_title = item       # book title
        
        # Check if the author is already in the result dictionary
        if author not in index_of_books:
            index_of_books[author] = [book_title]  # If not, add a new entry with the author and the book title in a list
        else:
            index_of_books[author].append(book_title)  # If yes, append the book title to the existing list of books by that author
    
    # Return the result dictionary
    return index_of_books

def report_author_counts(lib_fpath, rep_filepath):
    # Function of counts of books by each author to a file
    result = []
    
    # Open the library file in read mode and the report file in write mode
    myfile = open(lib_fpath, "r")
    myfile1 = open(rep_filepath, "w")
    with myfile as lib_fpath:
        with myfile1 as rep_filepath:
            # Go through each line in the library file
            for line in lib_fpath.readlines():
                line = line.strip("\n")
                splited = line.split("|")

                found = False
                # Check if the author is already in the result list
                for author in result:
                    if author[0] == splited[1]:
                        author[1] += 1  # If yes, do bigger the count by 1
                        found = True
                        break
                
                # If the author is not in the result list, add a new entry with count 1
                if not found:
                    result.append([splited[1], 1])
            
            total_books = 0
            # Write the author counts to the report file
            for author in result:
                rep_filepath.write(str(author[0]) + ": " + str(author[1]) + "\n")
                total_books += author[1]
            
            # Write the total number of books to the report file
            rep_filepath.write("TOTAL BOOKS: " + str(total_books))

    # Close the files
    myfile.close()
    myfile1.close()
