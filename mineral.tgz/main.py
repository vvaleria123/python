# a function that finds minimum path the robot went through
def find_min_path(max_mineral_paths):
    path = 2501
    for i in max_mineral_paths:
        x=0
        #pub1 i= [(3, 0), (3, 14), (10, 14), (10, 8)]
        #    i[0]      i[1]     i[2]      i[3]
        x+=(i[1][1]) + (i[2][0]-i[1][0]) + (i[2][1]-i[3][1]) + (i[3][0])
        if x<path:
            path=x
        # print(path,i)
    return path

def find_most_minerals_and_paths(field):
    if not field or not field[0]:
        return []
    rows = len(field)
    cols = len(field[0])
    max_mineral = 0
    max_mineral_paths = []
    # robot can move
    for i in range(1, rows-2):  # 1 starting point (i,0) the  robot can start the movement only from first col
        for j in range(1, cols-1):  # 2 first turn, down (i,j)
            for x in range(i+1, rows-1):  # 3 second turn, to the left (x,j)
                for y in range(1, j):  # 4 third turn, up (x,y)
                    # all points  (i, 0), (i, j), (x, j), (x, y)
                    visited = []
                    # remember the coordinates that are adjacent to the coordinate the robot stay in
                    for a in range(1, j):  # (i,a)
                        visited.append([i-1, a-1])
                        visited.append([i, a-1])
                        visited.append([i+1, a-1])
                        visited.append([i-1, a])
                        visited.append([i, a])
                        visited.append([i+1, a])
                        visited.append([i-1, a+1])
                        visited.append([i, a+1])
                        visited.append([i+1, a+1])

                    for b in range(i, x+1):  # (b,j)
                        visited.append([b-1, j-1])
                        visited.append([b, j-1])
                        visited.append([b+1, j-1])
                        visited.append([b-1, j])
                        visited.append([b, j])
                        visited.append([b+1, j])
                        visited.append([b-1, j+1])
                        visited.append([b, j+1])
                        visited.append([b+1, j+1])

                    for c in range(y, j):  # (x,c)
                        visited.append([x-1, c-1])
                        visited.append([x, c-1])
                        visited.append([x+1, c-1])
                        visited.append([x-1, c])
                        visited.append([x, c])
                        visited.append([x+1, c])
                        visited.append([x-1, c+1])
                        visited.append([x, c+1])
                        visited.append([x+1, c+1])

                    for d in range(1, x):  # (d,y)
                        visited.append([d-1, y-1])
                        visited.append([d, y-1])
                        visited.append([d+1, y-1])
                        visited.append([d-1, y])
                        visited.append([d, y])
                        visited.append([d+1, y])
                        visited.append([d-1, y+1])
                        visited.append([d, y+1])
                        visited.append([d+1, y+1])
                    # visited but without dublicates, checking
                    visited_v = []
                    for v in visited:
                        if v not in visited_v:
                            visited_v.append(v)
                    minerals=0
                    for m in visited_v:
                        minerals += field[m[0]][m[1]]

                    if max_mineral <= minerals:
                        if max_mineral == minerals: #the same max number of minerals
                            max_mineral_paths.append([(i, 0), (i, j), (x, j), (x, y)])

                        elif max_mineral < minerals: #new max number of minerals
                            max_mineral = minerals
                            max_mineral_paths = [[(i, 0), (i, j), (x, j), (x, y)]]
    return max_mineral, max_mineral_paths

# Input details
R, C = map(int, input().split())
field = [list(map(int, input().split())) for _ in range(R)]

max_mineral, max_mineral_paths=find_most_minerals_and_paths(field)
# Output
print(str(max_mineral) + " " + str(find_min_path(max_mineral_paths)))