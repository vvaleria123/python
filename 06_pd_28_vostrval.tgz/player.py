class MyPlayer:
    
    """
    Initializes a new player object for MyPlayer class

    Parameters:
        payoff_matrix (list of list of tuples, optional): A 2x2 matrix representing game's structure of payoff.
        number_of_iterations (int, optional): An integer that represents how many rounds the game will be played.
    Additional:
        self.my_last_move - Stores player's last move(set of None at the start)
        self.opponent_last_move - Stores opponent's last move(set of None at the start)
    
    """
    def __init__(self, payoff_matrix = 0, number_of_iterations = 0):
        self.payoff_matrix = payoff_matrix # matrix of tuples representing the structure of payoff
        self.number_of_iterations  = number_of_iterations # the integer that tell us how many rounds will be played
        self.my_last_move = 0  # Stores player's last move
        self.opponent_last_move = 0  # Stores opponent's last move

    """
    Determines last move of player using opponent's last move.

    Parameters:
        The metthod implements strategy. False means to stay silent (COOPERATE), True to betray (DEFECT).
        if the opponent cooperated(False), then the player will also cooperate (will return False). If the opponent defected (True), 
        the player will also defect (will return True).
    Returns:
        bool: Next move of player(False - cooperate, True - defect))

    """
    def move(self):
        if self.opponent_last_move is not True: # If the last move of oponent was cooperate - then cooperate
            return False
        return True # if oposite case - defect
    """
    Records the last moves of both(player and the opponent).

    Parameters:
        my_last_move(bool or None) - player's last move
        opponent_last_move(bool or None) - opponent's last move
    
    """
    def record_last_moves(self, my_last_move, opponent_last_move):
        self.record_my_last_move = my_last_move # Record player's last move
        self.record_opponent_last_move = opponent_last_move # Record opponent's last move
 
# payoff_matrix = ( ((4,4),(1,6)) , ((6,1),(2,2)) )
# number_of_iterations = 20
# player = MyPlayer(payoff_matrix, number_of_iterations)
