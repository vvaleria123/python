class Vector:
    def __init__(self,x):
        self.x = tuple(x)
        self.n = len(x)
        # """
        # constructor of the Vector class
        # input:
        # x - list or tuple of lenght
        # sets:
        # self.x - tuple: the vector values
        # self.n - vector length
        # >>> v = Vector([1,2,3])
        # """
 
    def scaled_copy(self,scale):
        multiplied_vect = []
        for cord in self.x:
            multiplied_vect.append(cord * scale)
        return Vector(multiplied_vect)

        # """ 
        # Isotropic scaling, scalar multiplication, in fact
        # https://en.wikipedia.org/wiki/Scaling_(geometry)
 
        # >>> v = Vector([1,2,3])
        # >>> v2 = v.scaled_copy(3)
        # >>> v.x
        # (1, 2, 3)
        # >>> v2.x
        # (3, 6, 9)
        # """
 
    def __add__(self,other):
        if self.n != other.n:
            return None
        added = []
        for i in range(self.n):
            added.append(self.x[i] + other.x[i])
        return Vector(added)

        # """
        # overloading the + operator
 
        # :return: Vector object result of the addition, None if not possible (not compatible vectors)
        # """