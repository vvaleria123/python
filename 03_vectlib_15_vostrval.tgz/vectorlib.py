def scalar_mult(sc,v):
    mult_vectors = []
    for i in range(len(v)):
        mult_vectors.append(v[i]*sc)
    return mult_vectors
# print(scalar_mult(2, [1,2,3,4,5]))

    # """
    # scalar multiplication (scalar * vector)
    # :param sc: a scalar mulitplier
    # :param v: a list - vector
    # :return: sc * v
    # """
 
def dot_product(u,v):
    vect_product = 0
    if len(u) == len(v):
        for i in range(len(u)):
            for j in range(len(v)):
                if i == j:
                    vect_product += u[i] * v[j]
        return vect_product
    else:
        return None
# print(dot_product([2,3,4,5], [2,3,4,5]))

#     # """
#     # # vector dot product
#     # # :param u: a list
#     # # :param v: a list
#     # # :return:
#     # # None if u and v are not compatible
#     # # otherwise a number (float or int)
#     # # """
 
def cross_product(u,v):
    
    if len(u) == 3 and len(v) == 3:
        
        result_of_cross_product = [u[1]*v[2] - u[2]*v[1],
            u[2]*v[0] - u[0]*v[2],
            u[0]*v[1] - u[1]*v[0]]
        return result_of_cross_product
    else:
        return None
# print(cross_product([1,2,3], [1,2,8]))
    # """
    # vector cross product, see
    # :param u: a list of lenght 3
    # :param v: a list of length 3
    # :return:
    # None if u and v are not compatible
    # a list of lenght 3 - cross product of u and v
    # """

 
def are_colinear(u,v):
    lst=[]
    if len(v) != len(u):
        return False
    for i in range(len(u)):
        if v[i]==0 or u[i]==0:
            if v[i] == 0 and u[i] == 0:
                pass
            else:
                return False
        else:
            lst.append(u[i]/v[i])
    for i in range(len(lst)):
        if u[i]==0 or v[i]==0:
            if u[i]==0 and v[i]!=0:
                return False
            if u[i]!=0 and v[i]==0:
                return False
            if u[i] == 0 and v[i] == 0:
                pass
        else:
            for i in range(len(u) - 1):
                if u[i] != 0 and v[i] != 0 and u[i+1] != 0 and v[i+1] != 0:
                     if u[i] / v[i] != u[i + 1] / v[i + 1]:
                        return False
    return True
#     # """
#     # testing colinearity of two vectors
#     # :param u: a list
#     # :param v: a list
#     # :return:
#     # True if u and v are colinear, False otherwise
#     # """
 
def are_perpendicular(u,v):
    if (u[0]*v[0])+(u[1]*v[1]) == 0:
        return True
    return False
# print(are_perpendicular ([1, 0], [0, 1]))
#     # """
#     # testing perpendicularity of two vectors
#     # :param u: a list
#     # :param v: a list
#     # :return:
#     # True if u and v are perpendicular, False otherwise
#     # """