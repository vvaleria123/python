def rectangle_corners(field):
    if not field or not field[0]:
        return []

    rows = len(field)
    cols = len(field[0])

    enclosures = []

  
    for i in range(rows):
        for j in range(cols):
            if field[i][j] == 1:
                if i < rows - 1 and j < cols - 1 and field[i + 1][j] == 1 and field[i][j + 1] == 1:
                    top_left = (i, j)

                    top_right = None
                    bottom_left = None
                    for k in range(j + 1, cols):
                        if field[i][k] != 1:
                            top_right = (i, k - 1)
                            break

                        else:
                            top_right = (i, cols - 1)
                   
                    for k in range(i + 1, rows):
                        if field[k][j] != 1:
                            bottom_left = (k - 1, j)
                            break
                        else:
                            bottom_left = (rows - 1, j)
                   
                    bottom_right = (max(top_left[0], bottom_left[0]), max(top_right[1], bottom_left[1]))

                    enclosures.append([top_left, top_right, bottom_left, bottom_right])

    return enclosures


def calculate_complexity_vertical(park, top_vertical, bottom_vertical):
    top_side=0
    bottom_side=0
    for i in range(park[1][1]-park[0][1]-1):
        for j in range(top_vertical[0]-park[0][0]-1):
           
            top_side+=field[park[0][0]+1+j][park[0][1]+1+i]
      

    for i in range(park[1][1]-park[0][1]-1):
        for j in range(park[2][0]-top_vertical[0]-1):
            bottom_side+=field[top_vertical[0]+1+j][park[0][1]+1+i]
  
   
    return (abs(top_side-bottom_side))

def calculate_complexity_horizontal(park, first_horizontal, last_horizontal):
    left_side=0
    right_side=0
    for i in range(first_horizontal[1]-1-park[0][1]):
        for j in range(last_horizontal[0]- first_horizontal[0]+1):
            left_side+=field[park[0][0]+1+j][park[0][1]+1+i]

    for i in range(park[1][1]-last_horizontal[1]-1):
        for j in range(last_horizontal[0]- first_horizontal[0]+1):
            right_side+=field[park[0][0]+1+j][last_horizontal[1]+1+i]
    
    return (abs(left_side-right_side))


def complexity(field):
    parks = rectangle_corners(field)
    complexities=[]
    for i in parks:
        l=0
        timed_complexities = []
        top_left2 = (i[0][0] + 1, i[0][1] + 1)
        for j in range(i[1][1] - i[0][1] - 3):
            if field[top_left2[0]][top_left2[1] + j + 1] == 0:
                q = 0
                for k in range(i[2][0] - i[1][0]-1):
                    if field[top_left2[0] + k][top_left2[1] + j + 1] != 0:
                        q = 1
                if q != 1:
                    l=1
                    timed_complexities.append(calculate_complexity_horizontal(i, (top_left2[0], top_left2[1] + j + 1),(i[2][0] - 1, top_left2[1] + j + 1)))
                    pass
        for j in range(i[2][0]-i[0][0]-3):
            if field[top_left2[0] + j + 1][top_left2[1]] == 0:
                p = 0
                for k in range(i[1][1]-i[0][1]-1):
                    if field[top_left2[0]+ j +1][top_left2[1] + k] !=0:
                        p = 1
                if p != 1:
                    l=1
                    timed_complexities.append(calculate_complexity_vertical(i, (top_left2[0]+j + 1,top_left2[1]),(top_left2[0]+j + 1,top_left2[1]+i[1][1]-i[0][1]-2)))
        if l==0:
            complexity_l=0            
            for y in range(i[2][0]-i[1][0]-1):
                for x in range(i[3][1]-i[2][1]-1):
                    complexity_l+=field[y+i[0][0] + 1][x+i[0][1] + 1]
            complexities.append(complexity_l)

        if len(timed_complexities)!=0:
            complexities.append(min(timed_complexities))
    return sum(complexities)


# Input details
# __________________________________________________________________________

R, C = map(int, input().split())
field = [list(map(int, input())) for _ in range(R)]

# Call the function to find rectangle corners
corners = rectangle_corners(field)

print(complexity(field))
