def hcf(a, b):
    """Calculate the highest common factor (hcf) of two numbers using Euclid's algorithm.
       Parameters:
    - a (int): The 1st number.
    - b (int): The 2nd number.

    Returns:
    - int: The HCF of the two numbers.
    """
    if a == 0: # If the 1st number(a) is 0, the HCF is the second number(b)
        return b
    else: # Apply Euclid's algorithm
        return hcf(b%a, a) # The HCF of a and b is the same as the HCF of b%a and a

class Fraction:
    """Creating class Fraction"""
    def __init__(self, numerator, denominator):
        """
    Initializes a Fraction object with simplified values.

    Parameters:
    numerator (int): The numerator of the fraction.
    denominator (int): The denominator of the fraction.

    Raises:
    ZeroDivisionError: If the denominator is zero.

    """
        gcd = hcf(numerator, denominator)
         # Simplify the fraction by dividing both(top and bottom) numerator and denominator by the GCD
        self.numerator = numerator // gcd  # top
        self.denominator = denominator // gcd  # bottom
        if denominator == 0:
            raise ZeroDivisionError
        
    def __str__ (self):
        """
    Returns a string representation of the Fraction object.

    - If the denominator is 1, it returns the numerator as a string.
    - If the denominator is -1, it returns the negative numerator as a string.
    - If the denominator is less than zero, it returns the negative numerator divided by the negative denominator as a string.
    - For all other cases, it returns the numerator divided by the denominator as a string.

    Returns:
    str: A string representation of the Fraction object.
    """
        if self.denominator == 1: # When the denominator is 1, return the numerator as a string
            return str(self.numerator)
        if self.denominator == -1: # When the denominator is -1, return the negative numerator as a string
            return str(self.numerator*(-1))
        if self.denominator<0: # When the denominator is less than zero, return the negative numerator divided by the negative denominator as a string
            return str(self.numerator*(-1)) + "/" + str(self.denominator*(-1))
        else: 
            # For all other cases, return the numerator divided by the denominator as a string
            return str(self.numerator) + "/" + str(self.denominator)
        
    def __add__(self, other):
        """
    Adds two Fraction objects and returns a new Fraction object as the result.

    Parameters:
    other (Fraction): The Fraction object to be added to the current Fraction.

    Returns:
    Fraction: A new Fraction object representing the result of the addition.
    """
        # Calculate the numerator and denominator to have the sum of fractions
        newnumer = self.numerator * other.denominator + other.numerator * self.denominator 
        newdenom = self.denominator * other.denominator
        return Fraction(newnumer, newdenom) # Create and return a new Fraction object representing the result
    
    def __sub__(self, other):
        """
    Subtracts two Fraction objects and returns a new Fraction object in the result.

    Parameters:
    other (Fraction): The Fraction object to be subtracted from the current Fraction.

    Returns:
    Fraction: A new Fraction object representing the result subtraction.
    """
        # Calculate the numerator and denominator for the subtraction of fractions
        newnumer = self.numerator * other.denominator - other.numerator * self.denominator
        newdenom = self.denominator * other.denominator
        return Fraction(newnumer, newdenom) # Create and return a new Fraction object representing the result
    
    def __mul__(self, other):
        """
    Multiplies two Fraction objects and returns a new Fraction object as the result.

    Parameters:
    other (Fraction): The Fraction object to be multiplied with the current Fraction.

    Returns:
    Fraction: A new Fraction object represented with the result of the multiplication.
    """
        # Calculate the numerator and denominator for the multiplication of fractions
        newnumer = self.numerator * other.numerator
        newbottom = self.denominator * other.denominator
        return Fraction(newnumer, newbottom) # Create and return a new Fraction object representing the result
    
    def __truediv__(self, other):
        """
    Divides two Fraction objects and returns a new Fraction object as the result.

    Parameters:
    other (Fraction): The Fraction object by which the current Fraction will be divided.

    Returns:
    Fraction: A new Fraction object representing the result of the division.
    """
        # Calculate the numerator and denominator for the division of fractions
        newnumer = self.numerator * other.denominator
        newbottom = self.denominator * other.numerator
        return Fraction(newnumer, newbottom) # Create and return a new Fraction object representing the result
    
    def __eq__(self, other):
        """
    Compares two Fraction objects for equality.

    Parameters:
    other (Fraction): The Fraction object that will be compared with the current Fraction.

    Returns:
    bool: True - if the two fractions are equal, False - otherwise.
    """
        return self.numerator * other.denominator == other.numerator * self.denominator 
    # Check if the fractions are equal by comparing their cross-products. 
    #(numerator of the first fraction multiply denominator of the second fraction
    # should be equal to numerator of the second fraction multiply denominator of the first fraction)
    
    def __lt__(self, other):
        """
    Compares two Fraction objects to check if the current fraction is less than the other fraction.

    Parameters:
    other (Fraction): The Fraction object to be compared with the current Fraction.

    Returns:
    bool: True - if the current fraction is less than the other, False - otherwise.
    """
        if self.denominator * other.denominator < 0: # Check if the denominators have opposite signs
            # For opposite signs, compare cross-products with reversed sign for less than
            return self.numerator * other.denominator > other.numerator * self.denominator
        if self.denominator * other.denominator > 0: # Check if the denominators have the same sign
            # For same sign, compare cross-products directly for less than
            return self.numerator * other.denominator < other.numerator * self.denominator
        
    def __le__(self, other):
        """
    Compares two Fraction objects to check if the current fraction is less than or equal to the other fraction.

    Parameters:
    other (Fraction): The Fraction object that will be compared with the current Fraction.

    Returns:
    bool: True - if the current fraction is less than or equal to the other, False - otherwise.
    """
        
        if self.denominator * other.denominator < 0: # Check if the denominators have opposite signs
            # For opposite signs, compare cross-products with reversed sign for less and equal(<=)
            return self.numerator * other.denominator > other.numerator*self.denominator or self.numerator*other.denominator == other.numerator*self.denominator
        if self.denominator * other.denominator > 0: # Check if the denominators have the same sign
            # For same sign, compare cross-products directly for less and equal(<=)
            return self.numerator * other.denominator < other.numerator * self.denominator or self.numerator * other.denominator == other.numerator * self.denominator
        
    def __gt__(self, other):
        """
    Compares two Fraction objects to check if the current fraction is greater than the other fraction.

    Parameters:
    other (Fraction): The Fraction object that will be compared with the current Fraction.

    Returns:
    bool: True - if the current fraction is greater than the other, False - otherwise.
    """
        if self.denominator * other.denominator < 0: # Check if the denominators have opposite signs
            # For opposite signs, compare cross-products with reversed sign for greater than
            return self.numerator * other.denominator < other.numerator * self.denominator
        if self.denominator * other.denominator > 0: # Check if the denominators have the same sign
            # For same sign, compare cross-products directly for greater than
            return self.numerator * other.denominator > other.numerator * self.denominator
        
    def __ge__(self, other):
        """
    Compares two Fraction objects to check if the current fraction is greater than or equal to the other fraction.

    Parameters:
    other (Fraction): The Fraction object that will be compared with the current Fraction.

    Returns:
    bool: True - if the current fraction is greater than or equal to the other, False - otherwise.
    """
        if self.denominator * other.denominator < 0:  # Check if the denominators have opposite signs
            # When denominators have opposite signs, compare cross-products to check if they are greater and equal(>=)
            return self.numerator * other.denominator < other.numerator * self.denominator or self.numerator * other.denominator == other.numerator*self.denominator
        if self.denominator * other.denominator > 0: # Check if the denominators have the same sign
            # When denominators have the same sign, compare cross-products directly for if they are greater and equal(>=)
            return self.numerator * other.denominator > other.numerator * self.denominator or self.numerator * other.denominator == other.numerator*self.denominator